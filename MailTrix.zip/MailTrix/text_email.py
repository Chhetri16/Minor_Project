
import smtplib
import ssl


smtp_port = 587                 
smtp_server = "smtp.gmail.com"  

email_from = "kgfmediaagency@gmail.com"
email_to = ["kgfmediaagency@gmail.com","sk111kushwaha@gmail.com","good121student@gmail.com","kamsaric@gmail.com","its.surajkushwaha@gmail.com"]

pswd = "ulob xacx lwqh gptr"



message = "it works"


simple_email_context = ssl.create_default_context()


try:
   
    print("Connecting to server...")
    TIE_server = smtplib.SMTP(smtp_server, smtp_port)
    TIE_server.starttls(context=simple_email_context)
    TIE_server.login(email_from, pswd)
    print("Connected to server :-)")
    
    # Send the actual email
    print()
    print(f"Sending email to - {email_to}")
    TIE_server.sendmail(email_from, email_to, message)
    print(f"Email successfully sent to - {email_to}")

except Exception as e:
    print(e)

finally:
    TIE_server.quit()





