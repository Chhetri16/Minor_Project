from django.shortcuts import render,HttpResponse
from django.core.mail import send_mail, EmailMessage
from django.contrib import messages
from django.conf import settings

def home(request):
        return render(request, 'index.html')

def mail(request):
    if request.method == "POST":
        tos = [email.strip() for email in (request.POST.get('email')).split(',')]
        subject = request.POST.get('subject')
        body = request.POST.get('body')
        attachment = request.FILES.get('file')
        # try:
        #     send_mail(
        #     subject=subject, message=body, from_email=settings.EMAIL_HOST_USER, recipient_list= tos, fail_silently=False)
        #     messages.success(request,("Your Emails Sent Successfully......."))
        # except Exception as e:
        #     return HttpResponse(f"Error sending emails: {e}")
    
        # return render(request, 'email.html',{'title':'Send Email'})
    
        try:
            email = EmailMessage(subject=subject, body=body, from_email=settings.EMAIL_HOST_USER, bcc=tos)
            # email.attach(attachment.name(),attachment.read(),attachment.content_type)
            email.send()
            messages.success(request,("Your Emails Sent Successfully......."))
        except Exception as e:
            messages.success(request, ("There is Some Error Kindly Try Again........"))
            return HttpResponse(f"Error sending emails: {e}")
    
        return render(request, 'email.html',{'title':'Send Email'})
        # print(tos,subject, body)
    else:
        messages.success(request,("Currently we are under Development and all emails will be sent by kgfmediaagency@gmail.com "))
        return render(request, 'email.html',{'title':'Send Email'})